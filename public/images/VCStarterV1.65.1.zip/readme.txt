
// VCStarter v1.65.1 by Brchi
// www.myCong.net
// admin@thearchifamily.com
// Visit www.vietcong.info

Just put all files into the Vietcong directory (and confirm overwriting).
In the \gifs folder you can find illustrations of the graphical options.

// CHANGES v1.65.1
- Fixed: Game crashed when activating an add-on by ingame menu

// CHANGES v1.65
- Added: Option "Correct aspect ratio (experimental, useful for widescreen)" (Choose your monitors native resolution)
- Added: Option "Fix menu flickering (may improve performance too)"
- Fixed: Improve texture filtering option caused invisible textures
- Fixed: Highlight bullets option did not work in replay mode or as delayed spectator

// CHANGES v1.6
- Added: Option "Multisample Anti-Aliasing"
- Added: Option "Disable player LODs"
- Added: Option "Fix Z-fighting"
- Added: Option "Highlight bullets (spectator only)" (Use arrow up/down key at least once as spectator to enable)
- Fixed: Unlock blood option did not always work
- Fixed: Limit FPS option slowed down loading screen
- Fixed: Direct3D 9 Error "GetAvailableTextureMem"

// CHANGES v1.5.1
- Option "Force player name ..." changed to "Fix resetting of player name/gamemode filter" and really works now
- Added requireAdministrator-manifest to vietcong.exe (Forces the game to start with admin rights)

// CHANGES v1.5
- Integrated Direct3D 8 to 9 converter (Always active, fixes low FPS on newer hardware, tested on AMD HD7xxx series)
- Removed HradBa support (VCStarter doesn't work on HradBa servers anymore!)